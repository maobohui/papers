# OFCRD

This repository contains the code for the ICASSP 2025 paper "Improving Student Learning with Orthogonal Fusion and Contrastive Relationship Distillation for Cross-lingual NER". The source code will be made public as soon as possible.
![alt text](https://github.com/maobohui/papers/blob/main/ISMD-OFCR/OFCRD.png)
